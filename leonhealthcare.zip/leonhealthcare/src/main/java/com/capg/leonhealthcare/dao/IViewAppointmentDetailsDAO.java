package com.capg.leonhealthcare.dao;

import java.util.List;



public interface IViewAppointmentDetailsDAO {

	@SuppressWarnings("rawtypes")
	public List viewAppointmentDetails(String UserId);

	
	
}

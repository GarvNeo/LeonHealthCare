 package com.capg.leonhealthcare.service;



import java.util.List;



public interface IViewAppointmentDetails {
	
	

	
	@SuppressWarnings("rawtypes")
	public List viewAppointmentDetail(String UserId);

	
} 

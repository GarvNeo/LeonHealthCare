package com.capg.leaonhealthcare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaonhealthcareApplicationTests {

	@Test
	void contextLoads() {
	}

}

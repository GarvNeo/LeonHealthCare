package com.user.repository;

import java.math.BigInteger;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.user.entity.UserEntity;

@Repository
public interface UserRepository extends CrudRepository<UserEntity, BigInteger>{
    
	
	@Query("select c from UserEntity c where c.id=?1 and c.password =?2")
	public UserEntity mapping(String id, String password);
	
	
}
